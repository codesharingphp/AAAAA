<?php include("header.php");?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Gallery</h2>
         <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit</p>
      </div>
    </div>
  </div>
</div>  
</section>


<section id="gallery" class="padding-top">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="work-filter">
          <ul class="text-center">
             <li><a href="javascript:;" data-filter="all" class="active filter">All</a></li>
             <li><a href="javascript:;" data-filter=".starters" class="filter"> Starters</a></li>
             <li><a href="javascript:;" data-filter=".drinks" class="filter">Free drinks </a></li>
             <li><a href="javascript:;" data-filter=".dinner" class="filter"> Dinner</a></li>
             <li><a href="javascript:;" data-filter=".lunch" class="filter">Breakfast & Lunch</a></li>
          </ul>
        </div>
 </div>
    </div>
     <div class="row">
      <div class="zerogrid">
        <div class="wrap-container">
          <div class="wrap-content clearfix">
            
       <?php 
  
           $q = "SELECT * FROM `products` ";
           $r = mysqli_query($connection,$q);
          while($row = mysqli_fetch_array($r))
           {
            ?>


            <div class="col-1-3 mix work-item starters heading_space">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="<?php echo 'admin/uploads/product/'.$row['productimage'];?>" alt="cook"/ style="width:400px;height:300px">
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="<?php echo 'admin/uploads/product/'.$row['productimage'];?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                  <div class="gallery_content">
                    <h3><a href="#">Spaghetti</a></h3>
                    <p>Duis autem vel eum iriure dolor</p>
                  </div> 
                </div>
              </div>
            </div>
       


       <?php } ?>
          </div>
        </div>
       </div>
      </div>
  </div>
</section>


<?php include("footer.php");?>